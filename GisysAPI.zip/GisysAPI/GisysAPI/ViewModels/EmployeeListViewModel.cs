﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GisysAPI.ViewModels
{
    public class EmployeeListViewModel
    {
        public List<EmployeeViewModel> ListOfEmployee { get; set; }
    }
}
